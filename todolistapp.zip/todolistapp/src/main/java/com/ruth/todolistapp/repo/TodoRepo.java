package com.ruth.todolistapp.repo;

import com.ruth.todolistapp.model.TodoItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TodoRepo extends JpaRepository<TodoItem, Long> {
}

